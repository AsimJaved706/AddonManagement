#include<iostream>
using namespace std;
int main()
{
char ch;
cout<<"enter any character";
cin>>ch;
if(ch>='A'&&ch<='z')
{
ch=ch+32;
cout<<ch;
}
else if(ch>='a'&&ch<='z')
{
ch=ch-32;
cout<<ch;
}
else
cout<<"wrong inputed character";
return 0;
}