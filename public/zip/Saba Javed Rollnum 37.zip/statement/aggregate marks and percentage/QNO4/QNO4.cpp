#include<iostream>
using namespace std;
int main()
{
int s1,s2,s3,avg;
cout<<"enter the marks of 1st subject";
cin>>s1;
cout<<"enter the marks of 2nd subject";
cin>>s2;
cout<<"enter the marks of 3rd subject";
cin>>s3;
avg=(s1+s2+s3)/3;
if(avg>=80)
cout<<"A Grade";
else if(avg>=70)
cout<<"(B Grade";
else if (avg>=60)
cout<<"C Grade";
else if(avg>=50)
cout<<"D Grade";
else
cout<<"fail";
return 0;
}
