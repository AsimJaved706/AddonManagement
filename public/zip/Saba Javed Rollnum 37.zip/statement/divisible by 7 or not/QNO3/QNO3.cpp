#include<iostream>
using namespace std;
int main()
{
int no;
cout<<"enter any no";
cin>>no;
switch(no%7)
{
case 0:
cout<<"divisble by 7";
break;
cout<<"Not divisble by 7";
}
return 0;
}