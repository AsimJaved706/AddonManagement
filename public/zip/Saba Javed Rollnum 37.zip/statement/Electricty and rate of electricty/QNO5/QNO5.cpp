#include<iostream>
using namespace std;
int main()
{
int cu,bill,netbill,tax;
cout<<"enter the consumed unit";
cin>>cu;
if(cu<=500)
netbill=cu*4;
else
{
bill=cu*5.5;
tax=bill*8/100;
netbill=bill+tax;
}
cout<<"net bill is"<<netbill;
return 0;
}