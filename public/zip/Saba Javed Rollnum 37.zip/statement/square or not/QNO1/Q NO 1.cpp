                          /*Question NO # 1
#include<iostream>
using namespace std;
int main()
{
int no1,no2;
cout<<"enter 1st no";
cin>>no1;
cout<<"enter 2nd no";
cin>>no2;
if((no1*no1)==no2
cout<<"2nd number is square number of 1st";
else
cout<<"2nd number is not square number of 1st";
return 0;
} 