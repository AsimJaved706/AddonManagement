#include<iostream>
using namespace std;
int main()
{
int no1,no2,no3,no4;
cout<<"enter the first no";
cin>>no1;
cout<<"enter the second no";
cin>>no2;
cout<<"enter the third no";
cin>>no3;
cout<<"enter the fourth no";
cin>>no4;
if(no1>no2 && no1>no3 && no1>no4)
cout<<"1st no is greater\n";
else if (no2>no1 && no2>no3 && no2>no4)
cout<<"2nd is greater\n";
else if (no3>no1 && no3>no2 && no3>no4)
cout<<"3rd no is greater\n";
else if (no4>no1 && no4>no2 && no4>no3);
cout<<"4th no is greater\n";
if else
cout<<"all nos are equal\n";
if(no1<no2 && no1<no3 && no1<no4)
cout<<"1st no is smallest\n";
else if (no2<no1 && no2<no3 && no2<no4)
cout<<"2nd no is smallest\n";
else if (no3<no1 && no3<no2 && no3<no4)
cout<<"3rd no is smallest\n";
else if (no4<no1 && no4<no2 && no4<no3)
cout<<"4th no is smallest\n";
if else
cout<<"all nos are equal\n";
return 0;

}

