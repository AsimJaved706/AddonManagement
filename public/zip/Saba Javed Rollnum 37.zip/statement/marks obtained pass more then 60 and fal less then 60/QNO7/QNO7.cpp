#include<iostream>
using namespace std;
int main()
{
int hwmarks,asstmarks,testmarks,obtmarks;
cout<<"enter home work marks";
cin>>hwmarks;
cout<<"enter assignment marks";
cin>>asstmarks;
cout<<"enter test marks";
cin>>testmarks;
obtmarks=(hwmarks*20/100)+(asstmarks*30/100)+(testmarks*50/100);
if(obtmarks>60)
cout<<"pass";
else
cout<<"fail";
return 0;
}
