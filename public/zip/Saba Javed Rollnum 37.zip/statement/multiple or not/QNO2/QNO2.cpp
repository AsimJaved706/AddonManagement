#include<iostream>
using namespace std;
int main()
{
int a,b;
cout<<"enter first number";
cin>>a;
cout<<"enter second number";
cin>>b;
if(a%b==0)
cout<<"b is the multiple of a";
else
cout<<"b is not a multiple of a";
return 0;
}